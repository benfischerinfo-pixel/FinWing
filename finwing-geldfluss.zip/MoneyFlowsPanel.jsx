import React, { useEffect, useState } from "react";
import { fetchTransactions } from "./transactionsClient";
import { ArrowDownRight, ArrowUpRight, Activity } from "lucide-react";

function formatEuro(value) {
  if (value === null || value === undefined || Number.isNaN(value)) return "0,00 €";
  return (
    value
      .toLocaleString("de-DE", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }) + " €"
  );
}

function getCurrentMonthRange() {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth(); // 0 = Januar

  const fromDate = new Date(year, month, 1);
  const toDate = new Date(year, month + 1, 0); // letzter Tag des Monats

  const toStr = (d) => d.toISOString().slice(0, 10); // YYYY-MM-DD

  return {
    label: fromDate.toLocaleDateString("de-DE", { month: "long", year: "numeric" }),
    from: toStr(fromDate),
    to: toStr(toDate),
  };
}

const MoneyFlowsPanel = () => {
  const [{ label, from, to }] = useState(getCurrentMonthRange);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        setError(null);
        const { transactions } = await fetchTransactions({
          from,
          to,
          limit: 1000,
        });
        setTransactions(transactions || []);
      } catch (err) {
        console.error(err);
        setError(err.message || "Fehler beim Laden der Geldflüsse");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [from, to]);

  const inflow = transactions.filter((t) => t.amount > 0);
  const outflow = transactions.filter((t) => t.amount < 0);

  const totalIn = inflow.reduce((sum, t) => sum + t.amount, 0);
  const totalOut = outflow.reduce((sum, t) => sum + t.amount, 0); // negativ
  const totalOutAbs = Math.abs(totalOut);
  const net = totalIn + totalOut; // da totalOut negativ ist

  const expenseByCategory = outflow.reduce((acc, t) => {
    const cat = t.category || "Unkategorisiert";
    const value = Math.abs(t.amount);
    acc[cat] = (acc[cat] || 0) + value;
    return acc;
  }, {});

  const topCategories = Object.entries(expenseByCategory)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);

  const totalFlow = totalIn + totalOutAbs || 1;

  return (
    <section className="rounded-[2rem] bg-[#0b0f18] border border-slate-800 p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-[10px] font-bold uppercase text-slate-500">
            Geldflüsse
          </div>
          <div className="text-xs text-slate-400">Zeitraum: {label}</div>
        </div>
        <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center border border-slate-700">
          <Activity className="w-4 h-4 text-emerald-400" />
        </div>
      </div>

      {loading ? (
        <p className="text-xs text-slate-400">Geldflüsse werden geladen…</p>
      ) : error ? (
        <p className="text-xs text-red-400">{error}</p>
      ) : transactions.length === 0 ? (
        <p className="text-xs text-slate-400">
          Für diesen Monat sind noch keine Transaktionen erfasst.
        </p>
      ) : (
        <>
          <div className="grid grid-cols-3 gap-3 text-xs">
            <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/30 p-3">
              <div className="flex items-center gap-1 text-[10px] text-emerald-300 uppercase font-bold mb-1">
                <ArrowUpRight className="w-3 h-3" />
                Zuflüsse
              </div>
              <div className="text-sm font-semibold text-emerald-100">
                {formatEuro(totalIn)}
              </div>
            </div>

            <div className="rounded-xl bg-red-500/5 border border-red-500/30 p-3">
              <div className="flex items-center gap-1 text-[10px] text-red-300 uppercase font-bold mb-1">
                <ArrowDownRight className="w-3 h-3" />
                Abflüsse
              </div>
              <div className="text-sm font-semibold text-red-200">
                {formatEuro(totalOutAbs)}
              </div>
            </div>

            <div className="rounded-xl bg-slate-900 border border-slate-700 p-3">
              <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">
                Netto-Cashflow
              </div>
              <div
                className={`text-sm font-semibold ${
                  net >= 0 ? "text-emerald-200" : "text-red-200"
                }`}
              >
                {formatEuro(net)}
              </div>
            </div>
          </div>

          <div className="mt-2">
            <div className="flex justify-between text-[10px] text-slate-500 mb-1">
              <span>Zuflüsse vs. Abflüsse</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden flex">
              <div
                className="h-full bg-emerald-500"
                style={{ width: `${(totalIn / totalFlow) * 100}%` }}
              />
              <div
                className="h-full bg-red-500/80"
                style={{ width: `${(totalOutAbs / totalFlow) * 100}%` }}
              />
            </div>
          </div>

          {topCategories.length > 0 && (
            <div className="mt-4">
              <div className="text-[10px] text-slate-500 uppercase font-bold mb-2">
                Top-Ausgabenkategorien
              </div>
              <div className="space-y-1">
                {topCategories.map(([cat, value]) => {
                  const pct = (value / totalOutAbs) * 100;
                  return (
                    <div key={cat} className="flex items-center justify-between gap-2">
                      <div className="flex-1">
                        <div className="flex justify-between text-[11px] text-slate-300">
                          <span>{cat}</span>
                          <span>{pct.toFixed(1)}%</span>
                        </div>
                        <div className="w-full h-1.5 rounded-full bg-slate-800 mt-1 overflow-hidden">
                          <div
                            className="h-full bg-red-500/80"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                      <div className="w-20 text-right text-[11px] text-slate-400 font-mono">
                        {formatEuro(value)}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </>
      )}
    </section>
  );
};

export default MoneyFlowsPanel;
