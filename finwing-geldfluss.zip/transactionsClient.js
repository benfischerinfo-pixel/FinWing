// Beispiel-Client, den MoneyFlowsPanel erwartet.
// Du kannst ihn in deinem Projekt z.B. unter `src/services/transactionsClient.js` ablegen.
const API_BASE_URL = import.meta.env?.VITE_API_BASE_URL || "http://localhost:4000";

export function apiUrl(path) {
  return `${API_BASE_URL}${path}`;
}

export async function fetchTransactions(params = {}) {
  const query = new URLSearchParams(params).toString();
  const resp = await fetch(apiUrl(`/api/transactions${query ? `?${query}` : ""}`));
  if (!resp.ok) throw new Error("Failed to load transactions");
  return resp.json(); // { transactions: [...] }
}
