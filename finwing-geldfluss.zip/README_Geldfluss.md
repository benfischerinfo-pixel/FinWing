# FinWing – Geldfluss-Modul (Cashflow Panel)

Dieses Paket enthält alles, was du für den **Geldfluss-Bereich** (Cashflow-Ansicht) brauchst:

- Eine React-Komponente `MoneyFlowsPanel.jsx`, die:
  - Transaktionen für den aktuellen Monat aus dem Backend lädt,
  - Zuflüsse, Abflüsse, Netto-Cashflow berechnet,
  - Top-Ausgabenkategorien anzeigt.
- Ein Beispiel, wie du sie im Cockpit einbindest: `CockpitView.withMoneyFlows.example.jsx`.
- Eine Kopie von `transactionsClient.js`, damit klar ist, welche API erwartet wird.

> Wichtig: Dieses Paket ist als Ergänzung zu deinem bestehenden FinWing-MVP gedacht, nicht als vollständiges Projekt.

---

## 1. Voraussetzungen

Damit das Geldfluss-Panel funktioniert, brauchst du:

1. Ein laufendes Backend mit Endpoint:

   - `GET /api/transactions?from=YYYY-MM-DD&to=YYYY-MM-DD&limit=...`

   Das Backend sollte Transaktionen aus Supabase lesen (so wie im Haupt-MVP-Paket vorbereitet).

2. Ein Frontend mit:

   - React
   - Den Service `fetchTransactions` aus `transactionsClient.js`.

Wenn du bereits das große `finwing-mvp.zip` eingebunden hast, ist das alles schon vorhanden.

---

## 2. Dateien in diesem Paket

### 2.1 `MoneyFlowsPanel.jsx`

- Holt Transaktionen für den aktuellen Monat.
- Berechnet:
  - **Zuflüsse** (alle Beträge > 0)
  - **Abflüsse** (alle Beträge < 0, als absolute Werte)
  - **Netto-Cashflow** (Zufluss + Abfluss)
- Zeigt eine einfache Auswertung der **Top-Ausgabenkategorien**.

Du kannst diese Datei nach:

```text
frontend/src/components/MoneyFlowsPanel.jsx
```

kopieren.

### 2.2 `CockpitView.withMoneyFlows.example.jsx`

Das ist eine Beispiel-Variante deiner `CockpitView.jsx`, in der:

- der bisherige Demo-Block stehen bleibt,
- das neue `MoneyFlowsPanel` eingefügt wird,
- darunter die KI-Komponente „Frag FinWing“ (`AskFinWingAI`).

Du kannst diese Datei nutzen, um deine bestehende `CockpitView.jsx` anzupassen.

### 2.3 `transactionsClient.js` (Referenz)

Eine Kopie des Services, den `MoneyFlowsPanel` benutzt.  
Wenn du diesen Service im Projekt schon hast, musst du nichts ändern.  
Wenn nicht, kannst du den Inhalt in dein Projekt übernehmen.

---

## 3. Einbau-Schritte (Kurzversion)

1. Kopiere die Dateien aus dieser ZIP in dein Projekt:
   - `MoneyFlowsPanel.jsx` nach `frontend/src/components/`
   - Inhalt von `CockpitView.withMoneyFlows.example.jsx` in deine `frontend/src/views/CockpitView.jsx` einarbeiten (oder Datei umbenennen).
   - `transactionsClient.js` nach `frontend/src/services/` (falls noch nicht vorhanden).

2. Stelle sicher, dass dein Backend läuft und `GET /api/transactions` wie im MVP-Paket implementiert ist.

3. Starte dein Frontend neu (`npm run dev`) und öffne das Cockpit:
   - Du solltest jetzt einen Bereich „Geldflüsse“ sehen, sobald Transaktionen im aktuellen Monat vorhanden sind.

---

## 4. Wie du testest, ob es funktioniert

1. Stelle sicher, dass du in Supabase in der Tabelle `transactions` ein paar Datensätze hast:
   - Spalte `amount` positiv für Einnahmen, negativ für Ausgaben.
   - Spalte `category` sinnvoll befüllt (z.B. `food_cost`, `personal`, `miete`, …).

2. Rufe dein Cockpit im Browser auf:
   - Der Geldfluss-Bereich sollte dir nun Zuflüsse, Abflüsse, Netto-Cashflow und Top-Kategorien anzeigen.

Wenn im aktuellen Monat keine Transaktionen vorhanden sind, erscheint eine Hinweismeldung.

---

So kannst du den Geldfluss-Bereich gezielt isoliert weitergeben oder einbauen, ohne im großen Gesamtprojekt suchen zu müssen.
